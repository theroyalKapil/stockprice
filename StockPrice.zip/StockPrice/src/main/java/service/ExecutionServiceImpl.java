package service;

import service.ExecutionService;

public class ExecutionServiceImpl implements ExecutionService {
    public void buy(String security, double price, int volume) {
        //Some logic to buy stock
    }

    public void sell(String security, double price, int volume) {
        //Some logic for sell stock
    }
}
