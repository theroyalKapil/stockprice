package service;

public interface PriceListener {
    void priceUpdate(String security, double price);
}
