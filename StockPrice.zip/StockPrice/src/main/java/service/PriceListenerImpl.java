package service;

import service.PriceListener;

public class PriceListenerImpl implements PriceListener {
    public void priceUpdate(String security, double price) {



    }
}
