import org.junit.Test;

import static org.junit.Assert.*;

public class PriceExecuterTest {

    @Test
    public void priceExecuter() {
        PriceExecuter priceExecuter = new PriceExecuter();
        priceExecuter.priceExecuter();
    }
}